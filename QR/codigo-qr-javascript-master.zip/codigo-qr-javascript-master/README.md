# Como Generar Códigos QR con Javascript

### [Tutorial: https://youtu.be/xWx9_GVHa_k](https://youtu.be/xWx9_GVHa_k)

![Como Generar Códigos QR con Javascript](https://raw.githubusercontent.com/falconmasters/codigo-qr-javascript/master/img/thumb.png)

Por: [FalconMasters](http://www.falconmasters.com)
